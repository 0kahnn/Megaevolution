export const faqData = [
  {
    title: "General",
    data: [
      {
        title: "General ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "General ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
    ],
  },
  {
    title: "Creators",
    data: [
      {
        title: "Creators ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Creators ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
    ],
  },
  {
    title: "Metaverse Teams",
    data: [
      {
        title: "Metaverse ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
    ],
  },
  {
    title: "Clients",
    data: [
      {
        title: "Clients ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
      {
        title: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
        description:
          "Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis error, ea molestiae perspiciatis magni, iusto optio sapiente aliquam harum accusantium voluptate inventore deleniti libero quam totam beatae nesciunt, nisi quod? ",
      },
    ],
  },
];
