export const menuItems = [
  {
    name: "Home",
    link: "/",
    marketting: false,
    myspace: false,
    header: true,
  },
  {
    name: "Events",
    link: "/",
    marketting: false,
    myspace: false,
    header: true,
  },
  {
    name: "Partner",
    link: "/",
    marketting: false,
    myspace: false,
    header: true,
  },
  {
    name: "Roadmap",
    link: "/",
    marketting: false,
    myspace: false,
    header: true,
  },
  {
    name: "Team",
    link: "/",
    marketting: false,
    myspace: false,
    header: true,
  },

  {
    name: "MEGA Mansion",
    link: "/",
    marketting: false,
    myspace: false,
    header: true,
  },
  {
    name: `Maketing <span>Home</span>`,
    link: "/",
    marketting: true,
    myspace: false,
    header: false,
  },
  {
    name: `My Space`,
    link: "/",
    marketting: false,
    myspace: true,
    header: false,
  },
];
