const Spacer = ({ height }) => {
  return <div style={{ marginTop: `${height}rem` }}></div>;
};
export default Spacer;
