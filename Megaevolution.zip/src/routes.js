import Auth from "./Views/Auth/Auth";
export const routes = [
  {
    component: Auth,
    Path: "/",
  },
];
